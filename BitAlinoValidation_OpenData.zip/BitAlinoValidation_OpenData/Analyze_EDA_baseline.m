function [output] = Analyze_EDA_baseline()
%ANALYZE_EDA_baseline - written by Katie O'Connell, IPN Georgetown Dec 2017
%see ANALYZE_EDA for descriptions

%%%%%%%%%                  %%%%%%%%%
%%%%%%%%%     BASELINE     %%%%%%%%%
%%%%%%%%%                  %%%%%%%%%

P = pwd ;

subjects={'101','110', '111', '112', '115', '120','122','126','130','102','106', '109', '116', '118','123','127','131','104','107','113', '117', '121','128','132','105','108','114','119','129','133'};
for k=1:length(subjects)
    cursub=subjects{k};

resfile = sprintf('%s/results/results_baseline.txt',P);
subdir = sprintf('%s/subjects/%s',P,cursub);
baseline = sprintf('%s/%s-Baseline.txt',subdir,cursub);

searchSR = fileread(baseline); % CHECKING THAT SAMPLING RATE = 100Hz
SR = strfind(searchSR,'"sampling rate": 100,','ForceCellOutput',true);
SRthinkpad = strfind(searchSR,'"SamplingFrequency": "100",','ForceCellOutput',true);
    if isempty(SR{:}) > 0 || isempty(SRthinkpad{:}) > 0  % then continue        
       
        cd(subdir)
        %import EDA data
        EDA_raw_baseline = dlmread(baseline,'\t',2,1);

        %ANALYSIS 
                   V = EDA_raw_baseline(200:30200,5); % get matrix for 5 minutes with 2s delay
                   [M,I] = max(V);
                   [m,i] = min(V);
                   x = mean(V);

                   %write data to results file
                   shawn=strcat(cursub, {' '}, num2str(M), {' '}, num2str(I), {' '}, num2str(m), {' '}, num2str(i), {' '}, num2str(x));
                   fileID = fopen(resfile,'at');
                   fprintf(fileID,shawn{1});
                   fprintf(fileID,'\n');
                   fclose(fileID);
                  
        
    else
        error ('check your sampling rate')
    end %end if sample rate loop
end %end subject loop
cd(P);